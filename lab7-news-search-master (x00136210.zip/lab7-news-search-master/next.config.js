// next.config.js
// https://nextjs.org/docs#custom-configuration

module.exports = {
    /* config options here */

  }
  