const Header = () => (
    <div>
        <h2 className="title">My News Site</h2>
        <style jsx>{`


            h2.title {
                font-family: "Arial";
                color: #535151;
                padding: 5px;
            }


        `}</style>
    </div> 
 )
 
 export default Header;