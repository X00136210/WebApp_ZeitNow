// Footer component
const Footer = () => (
    <div>
        <footer>
            <link href="https://newsapi.org/">Powered by News API</link>
        </footer>
        <style jsx>{`
            footer {
                background-color: #a19f9f;
                max-width: 900px;
                font-size: 0.8em;
                text-align: center;
                color: #a19f9f;
                clear: both;
            }
        `}</style>
    </div> 
 )
 
 export default Footer;